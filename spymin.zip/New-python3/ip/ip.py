import os
from colorama import Fore
from time import sleep

ip = input(Fore.LIGHTGREEN_EX+"please ip Target"+Fore.LIGHTRED_EX+": "+Fore.LIGHTWHITE_EX)
print("")
sleep(2)
print("")
print(Fore.LIGHTGREEN_EX+"<=========== "+Fore.LIGHTWHITE_EX+"MR - DARK"+Fore.LIGHTGREEN_EX+" ===========>")
print()
print(Fore.LIGHTYELLOW_EX+"IP Address "+Fore.LIGHTCYAN_EX+": "+Fore.LIGHTGREEN_EX+ip)
print(Fore.LIGHTYELLOW_EX+"City "+Fore.LIGHTCYAN_EX+": "+Fore.LIGHTGREEN_EX+"America")
print(Fore.LIGHTYELLOW_EX+"Region "+Fore.LIGHTCYAN_EX+": "+Fore.LIGHTGREEN_EX+"Brelin")
print(Fore.LIGHTYELLOW_EX+"Country "+Fore.LIGHTCYAN_EX+": "+Fore.LIGHTGREEN_EX+"America")
print(Fore.LIGHTYELLOW_EX+"Latitude "+Fore.LIGHTCYAN_EX+": "+Fore.LIGHTGREEN_EX+"30.1754")
print(Fore.LIGHTYELLOW_EX+"Time Zone "+Fore.LIGHTCYAN_EX+": "+Fore.LIGHTGREEN_EX+"America/English")
print(Fore.LIGHTYELLOW_EX+"Postal Code "+Fore.LIGHTCYAN_EX+": "+Fore.LIGHTGREEN_EX+"6544")
print(Fore.LIGHTYELLOW_EX+"ASN "+Fore.LIGHTCYAN_EX+": "+Fore.LIGHTGREEN_EX+"A123564")
print(Fore.LIGHTYELLOW_EX+"Country Code "+Fore.LIGHTCYAN_EX+": "+Fore.LIGHTGREEN_EX+"EN")
print(Fore.LIGHTYELLOW_EX+"Currency "+Fore.LIGHTCYAN_EX+": "+Fore.LIGHTGREEN_EX+"Dollar")
print(Fore.LIGHTYELLOW_EX+"Calling Code "+Fore.LIGHTCYAN_EX+": "+Fore.LIGHTGREEN_EX+"+1")