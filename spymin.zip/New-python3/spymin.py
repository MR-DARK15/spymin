from colorama import Fore
from time import sleep
from sys import version_info
import sys
import os

if version_info < (3,0,0):
  print(Fore.LIGHTGREEN_EX+"["+Fore.LIGHTRED_EX+"!"+Fore.LIGHTGREEN_EX+"]"+Fore.LIGHTYELLOW_EX+" Please use Python"+Fore.LIGHTGREEN_EX+" 3.0.0 "+Fore.LIGHTRED_EX+"$ "+Fore.LIGHTYELLOW_EX+"python3 spymin.py")
  sys.exit()

print("")

print(Fore.LIGHTRED_EX+"""

-//.
                    `yddddo`
           -oho.   .sddddddo`   -oh+.
        ./ys:`/ys:odddddddddd+/yy:`/yy/`
      `sy/`     /ddddohsohsdddd-     .+ys`
           .:`  yddds++++++ydddo  `:.
         .ohoho/dd+s-ooooo+++odd:ohoho.
       .oh/` `:yddsh-ooooo++yydds:  `+ho.
    .`      +ssssddddhdhhdhddddssss+      `.
           +d-    .sddddddddo.  ``-d/
          /d-       `-///:-        :d:
         :d:                        /d-
        -d/                          +d.
        .:                            :-
         +------------------------------+
         |github.com/MR-DARK15          |
         |t.me/name_MR_DARK             |
         |[salman - hacker]             |
         +------------------------------+

""")
print("--------------------     --------------------")
print(Fore.LIGHTWHITE_EX+"["+Fore.LIGHTGREEN_EX+"+"+Fore.LIGHTWHITE_EX+"]"+" link_virus         "+Fore.LIGHTWHITE_EX+"["+Fore.LIGHTGREEN_EX+"link virus the mokharab"+Fore.LIGHTWHITE_EX+"] ")
print(Fore.LIGHTWHITE_EX+"["+Fore.LIGHTGREEN_EX+"+"+Fore.LIGHTWHITE_EX+"]"+Fore.LIGHTWHITE_EX+" Hack_web           "+Fore.LIGHTWHITE_EX+"["+Fore.LIGHTGREEN_EX+"Hack information website"+Fore.LIGHTWHITE_EX+"]")
print(Fore.LIGHTWHITE_EX+"["+Fore.LIGHTGREEN_EX+"+"+Fore.LIGHTWHITE_EX+"]"+Fore.LIGHTWHITE_EX+" banner             "+Fore.LIGHTWHITE_EX+"["+Fore.LIGHTGREEN_EX+"Create the banner"+Fore.LIGHTWHITE_EX+"]")
print(Fore.LIGHTWHITE_EX+"["+Fore.LIGHTGREEN_EX+"+"+Fore.LIGHTWHITE_EX+"]"+Fore.LIGHTWHITE_EX+" Admin_Finder   "+Fore.LIGHTWHITE_EX+"    ["+Fore.LIGHTGREEN_EX+"Admin the login"+Fore.LIGHTWHITE_EX+"]")
print(Fore.LIGHTWHITE_EX+"["+Fore.LIGHTGREEN_EX+"+"+Fore.LIGHTWHITE_EX+"]"+Fore.LIGHTWHITE_EX+" cls   "+Fore.LIGHTWHITE_EX+"             ["+Fore.LIGHTGREEN_EX+"clear the menu"+Fore.LIGHTWHITE_EX+"]")
print(Fore.LIGHTWHITE_EX+"["+Fore.LIGHTGREEN_EX+"+"+Fore.LIGHTWHITE_EX+"]"+Fore.LIGHTWHITE_EX+" Hack_ip   "+Fore.LIGHTWHITE_EX+"         ["+Fore.LIGHTGREEN_EX+"Hack information ip"+Fore.LIGHTWHITE_EX+"]")
print(Fore.LIGHTWHITE_EX+"["+Fore.LIGHTGREEN_EX+"+"+Fore.LIGHTWHITE_EX+"]"+Fore.LIGHTWHITE_EX+" Information_Device "+Fore.LIGHTWHITE_EX+"["+Fore.LIGHTGREEN_EX+"Hack Information_Device"+Fore.LIGHTWHITE_EX+"]")
print(Fore.LIGHTWHITE_EX+"["+Fore.LIGHTGREEN_EX+"+"+Fore.LIGHTWHITE_EX+"]"+Fore.LIGHTWHITE_EX+" Exit_menu "+Fore.LIGHTWHITE_EX+"         ["+Fore.LIGHTGREEN_EX+"Exit the menu"+Fore.LIGHTWHITE_EX+"]")

while True:
  print("")
  mun = input(Fore.LIGHTYELLOW_EX+"root"+Fore.LIGHTGREEN_EX+"@"+Fore.LIGHTYELLOW_EX+"dark"+Fore.LIGHTRED_EX+"~"+Fore.LIGHTGREEN_EX+"$ "+Fore.LIGHTWHITE_EX)

  if mun == "link_virus":
    print("")
    li = input(Fore.LIGHTYELLOW_EX+"link install? (No/Yes): ")
    
    if li == "Yes":
      print(Fore.LIGHTGREEN_EX+"Loading....")
      sleep(2)
      print("")
      print(Fore.LIGHTRED_EX+"Link: "+Fore.LIGHTYELLOW_EX+"https://tinyurl.com/game-play-xxx"+Fore.LIGHTWHITE_EX)
      print("")
    else:
      print(Fore.LIGHTGREEN_EX+"Ok")
    
  if mun == "Hack_web":
    print("")
    web = input(Fore.LIGHTGREEN_EX+"Enter Target: ")
    print("")
    site = site.replace("https://","")
    site = site.replace("http://","")
    site = site.replace("www.","")
    
    if site[-3:] == "org":
      server = "whois.internic.net"
    else:
      server = "whois.iana.org"
      
    s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    s.connect((server,43))
    s.send((site+"\r\n").encode())
    
    msg = s.recv(10000)
    print(msg.decode())
    print("")

  if mun == "banner":
    print(Fore.LIGHTRED_EX+"""

  -//.
                      `yddddo`
             -oho.   .sddddddo`   -oh+.
          ./ys:`/ys:odddddddddd+/yy:`/yy/`
        `sy/`     /ddddohsohsdddd-     .+ys`
             .:`  yddds++++++ydddo  `:.
           .ohoho/dd+s-ooooo+++odd:ohoho.
         .oh/` `:yddsh-ooooo++yydds:  `+ho.
      .`      +ssssddddhdhhdhddddssss+      `.
             +d-    .sddddddddo.  ``-d/
            /d-       `-///:-        :d:
           :d:                        /d-
          -d/                          +d.
          .:                            :-
           +------------------------------+
           |github.com/MR-DARK15          |
           |t.me/name_MR_DARK             |
           |[salman - hacker]             |
           +------------------------------+
  
    """)
    print("--------------------     --------------------")
    print(Fore.LIGHTWHITE_EX+"["+Fore.LIGHTGREEN_EX+"+"+Fore.LIGHTWHITE_EX+"]"+" link_virus         "+Fore.LIGHTWHITE_EX+"["+Fore.LIGHTGREEN_EX+"link virus the mokharab"+Fore.LIGHTWHITE_EX+"] ")
    print(Fore.LIGHTWHITE_EX+"["+Fore.LIGHTGREEN_EX+"+"+Fore.LIGHTWHITE_EX+"]"+Fore.LIGHTWHITE_EX+" Hack_web           "+Fore.LIGHTWHITE_EX+"["+Fore.LIGHTGREEN_EX+"Hack information website"+Fore.LIGHTWHITE_EX+"]")
    print(Fore.LIGHTWHITE_EX+"["+Fore.LIGHTGREEN_EX+"+"+Fore.LIGHTWHITE_EX+"]"+Fore.LIGHTWHITE_EX+" banner             "+Fore.LIGHTWHITE_EX+"["+Fore.LIGHTGREEN_EX+"Create the banner"+Fore.LIGHTWHITE_EX+"]")
    print(Fore.LIGHTWHITE_EX+"["+Fore.LIGHTGREEN_EX+"+"+Fore.LIGHTWHITE_EX+"]"+Fore.LIGHTWHITE_EX+" Admin_Finder   "+Fore.LIGHTWHITE_EX+"    ["+Fore.LIGHTGREEN_EX+"Admin the login"+Fore.LIGHTWHITE_EX+"]")
    print(Fore.LIGHTWHITE_EX+"["+Fore.LIGHTGREEN_EX+"+"+Fore.LIGHTWHITE_EX+"]"+Fore.LIGHTWHITE_EX+" cls   "+Fore.LIGHTWHITE_EX+"             ["+Fore.LIGHTGREEN_EX+"clear the menu"+Fore.LIGHTWHITE_EX+"]")
    print(Fore.LIGHTWHITE_EX+"["+Fore.LIGHTGREEN_EX+"+"+Fore.LIGHTWHITE_EX+"]"+Fore.LIGHTWHITE_EX+" Hack_ip   "+Fore.LIGHTWHITE_EX+"         ["+Fore.LIGHTGREEN_EX+"Hack information ip"+Fore.LIGHTWHITE_EX+"]")
    print(Fore.LIGHTWHITE_EX+"["+Fore.LIGHTGREEN_EX+"+"+Fore.LIGHTWHITE_EX+"]"+Fore.LIGHTWHITE_EX+" Information_Device "+Fore.LIGHTWHITE_EX+"["+Fore.LIGHTGREEN_EX+"Hack Information_Device"+Fore.LIGHTWHITE_EX+"]")
    print(Fore.LIGHTWHITE_EX+"["+Fore.LIGHTGREEN_EX+"+"+Fore.LIGHTWHITE_EX+"]"+Fore.LIGHTWHITE_EX+" Exit_menu "+Fore.LIGHTWHITE_EX+"         ["+Fore.LIGHTGREEN_EX+"Exit the menu"+Fore.LIGHTWHITE_EX+"]")
  
  if mun == "Admin_Finder":
    print("")
    os.system("cd admin && python admin_Finder.py")

  if mun == "cls":
    os.system("clear")

  if mun == "Hack_ip":
    print("")
    os.system("cd ip && python ip.py")

  if mun == "Information_Device":
    os.system("cd number && python number.py")
  
  if mun == "Exit_menu":
    print("")
    sleep(2)
    print(Fore.LIGHTYELLOW_EX+"["+Fore.LIGHTGREEN_EX+"Tanks you"+Fore.LIGHTYELLOW_EX+"]")
    print("")
    exit()
